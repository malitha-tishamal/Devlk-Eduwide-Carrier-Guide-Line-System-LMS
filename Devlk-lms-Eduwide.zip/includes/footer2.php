<div class="credits">
    Developed by <a href="developers.php">Devlk Team</a>
</div>