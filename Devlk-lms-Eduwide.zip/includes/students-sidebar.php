<!-- ======= Sidebar ======= -->
<aside id="sidebar" class="sidebar">
    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item">
            <a class="nav-link" href="pages-home.php">
                <i class="bi bi-house-door"></i> <span>Home</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-toggle="collapse" href="#course-nav" role="button">
                <i class="bi bi-book"></i> <span>Course Content</span> <i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="course-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
                <li>
                    <a href="pages-courses.php">
                        <i class="bi bi-circle"></i> <span>Course Content</span>
                    </a>
                </li>
            </ul>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-toggle="collapse" href="#admins-nav" role="button">
                <i class="bi bi-bookmark-dash"></i> <span>My Marks</span> <i class="bi bi-chevron-down ms-auto"></i>
            </a>
            <ul id="admins-nav" class="nav-content collapse" data-bs-parent="#sidebar-nav">
                <li>
                    <a href="pages-semester1.php">
                        <i class="bi bi-circle"></i> <span>Semester 1</span>
                    </a>
                </li>
                <li>
                    <a href="pages-semester2.php">
                        <i class="bi bi-circle"></i> <span>Semester 2</span>
                    </a>
                </li>
                <li>
                    <a href="pages-semester3.php">
                        <i class="bi bi-circle"></i> <span>Semester 3</span>
                    </a>
                </li>
                <li>
                    <a href="pages-semester4.php">
                        <i class="bi bi-circle"></i> <span>Semester 4</span>
                    </a>
                </li>
            </ul>
        </li>

        

        <li class="nav-item">
            <a class="nav-link collapsed" href="user-profile.php">
                <i class="bi bi-person-circle"></i> <span>Profile</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link collapsed" href="logout.php">
                <i class="bi bi-box-arrow-right"></i> <span>Log Out</span>
            </a>
        </li>

    </ul>
</aside><!-- End Sidebar -->
