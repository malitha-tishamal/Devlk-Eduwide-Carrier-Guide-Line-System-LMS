# Devlk-Team-Eduwide

Cloning this Repo
* Use GitHub Desktop to Clone and Working with this Repo.

* You Don't need to make a folder for clone this repo.
Clone this to:
   for Xampp Users -> C:\xampp\htdocs
   for Wamp Users -> C:\wamp\www

Dtabase Setup
You need to make a database name like 'eduwide' for open this project in your localhost.
Localhost Database Name = eduwide


Attention to these things
* Before start the works, you have to pull the project.
* Don't edit codes, without asking from @malitha.

Best Practices
* You have to name custom css classes like this -> my-heading
* You have to name custom ids like this -> idOne
* When naming functions, use a name taht describes what the function does ->
